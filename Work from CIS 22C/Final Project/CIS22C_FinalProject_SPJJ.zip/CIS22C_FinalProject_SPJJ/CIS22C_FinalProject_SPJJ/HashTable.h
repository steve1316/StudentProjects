#ifndef HASHTABLE_H
#define HASHTABLE_H

#include "HashNode.h"
#include "SmashHero.h"

class HashTable {
private:
	const int tableSize = 101;
	HashNode** hTable;
	int collisions;
	double currentSize;

public:
	HashTable();
	~HashTable();
	int Hash(int key);
	int getCollisions();
	SmashHero* getItem(int key);
	void addItem(SmashHero* data);
	void removeItem(int key);
	void displayEfficiency();

	friend ostream& operator<<(ostream& os, HashTable& hashTable);
};

#endif HASHTABLE_H
#include <iostream>
#include <string>
#include <fstream>
#include <ctime>

#include "HashTable.h"
#include "BST.h"
#include "SmashHero.h"
#include "Database.h"

using namespace std;

void displayLoadingScreen();
void displayMainMenu(Database<SmashHero>& database);

void battleMenu(Database<SmashHero>& database, bool battleHelp);
void purchaseMenu(Database<SmashHero>& database);
void sellMenu(Database<SmashHero>& database);
void heroListMenu(Database<SmashHero>& database);
void teamMenu(Database<SmashHero>& database);
void optionsMenu(Database<SmashHero>& database);

int main() 
{
	srand(time(0));		// use current time as seed.
	displayLoadingScreen();
	cout << "Initializing database...\n";
	Database<SmashHero> database;
	cout << "Database successfully intialized.\n\n";

	bool battleHelp = true;

	system("pause");
	bool ExitMainMenu = false;
	do {
		system("cls");
		displayMainMenu(database);
		int userChoice;
		cin >> userChoice;
		switch (userChoice) 
		{
		case 1:
			system("cls");
			battleMenu(database, battleHelp);
			battleHelp = false;
			break;
		case 2:
			system("cls");
			purchaseMenu(database);
			break;
		case 3:
			system("cls");
			sellMenu(database);
			break;
		case 4:
			system("cls");
			heroListMenu(database);
			break;
		case 5:	
			system("cls");
			teamMenu(database);
			break;
		case 6:
			system("cls");
			optionsMenu(database);
			break;
		case 7:
			ExitMainMenu = true;
			break;
		default:
			break;
		}
		system("pause");
	} while (!ExitMainMenu);
	return 0;
}

void displayLoadingScreen() 
{
	cout << "=================================================" << endl;
	cout << "===================Smash Heroes==================\n";
	cout << "=================================================" << endl;
	cout << "Loading...\n";
	cout << "Loading SaveFile.txt...\n";
}

void displayMainMenu(Database<SmashHero>& database) 
{
	if (database.getTeamMember(1) == nullptr || database.getTeamMember(2) == nullptr || database.getTeamMember(3) == nullptr || database.getTeamMember(4) == nullptr || database.getTeamMember(5) == nullptr) {
		cout << "=================================================" << endl;
		cout << "====================Main Menu====================" << endl;
		cout << "=================================================" << endl;
		cout << "1. To Battle!\t\t\t" << "Gold: " << database.getGold() << endl;
		cout << "2. Purchase New Hero\t\t" << endl;
		cout << "3. Sell Hero\t\t\t" << endl;
		cout << "4. Hero List\t\t\t"  << endl;
		cout << "5. Team Menu\t\t\t" << endl;
		cout << "6. Options Menu\t\t\t" << endl;
		cout << "7. Exit Game\t\t\t" << endl << endl;
	}
	else {
		cout << "=================================================" << endl;
		cout << "====================Main Menu====================" << endl;
		cout << "=================================================" << endl;
		cout << "1. To Battle!\t\t\t" << "Gold: " << database.getGold() << endl;
		cout << "2. Purchase New Hero\t\t" << "Team Members" << endl;
		cout << "3. Sell Hero\t\t\t" << *database.getTeamMember(1) << endl;
		cout << "4. Hero List\t\t\t" << *database.getTeamMember(2) << endl;
		cout << "5. Team Menu\t\t\t" << *database.getTeamMember(3) << endl;
		cout << "6. Options Menu\t\t\t" << *database.getTeamMember(4) << endl;
		cout << "7. Exit Game\t\t\t" << *database.getTeamMember(5) << endl << endl;
	}
}

/*
Battle Menu

Display the team on a special battle screen
use Database::teamBattle() to get the rewards
Display gold added and increased stats?
*/
void battleMenu(Database<SmashHero>& database, bool battleHelp) 
{
	double goldCost = 100;
	int choice;
	cout << "==================================================" << endl;
	cout << "===================Battle Menu====================" << endl;
	cout << "==================================================" << endl;

	if (battleHelp == true)
	{
		cout << "-Here is an explanation of the various systems at work here:" << endl;
		cout << "-Battles go automatically with no need for user input." << endl;
		cout << "-Both your party and a random enemy party are assigned a turn order for each member so everyone gets a turn." << endl;
		cout << "-When member A attacks member B, B's DEF stat is subtracted from A's ATK stat to get the final ATK stat." << endl;
		cout << "-Attacks have a base chance to miss." << endl;
		cout << "-If member B's DEF stat is higher than A's ATK stat, A's ATK stat will be set to a base minimum that scales with B's level." << endl;
		cout << "-When HP goes to 0, that member is knocked out. You can pay to heal up your current team back in the Battle Menu." << endl;
		cout << "-You win by knocking out the entire enemy team and lose when your entire team gets knocked out. You earn gold and EXP regardless of win or lost." << endl;
		cout << "-You have a chance to randomly increase your earnings of gold and EXP." << endl;
		cout << "-If EXP >= 100, then you level up. You gain base stat increases (ATK+) as well as a random chance for more stat increases (ATK+ and DEF+++)." << endl;
		system("PAUSE");
		system("cls");
		cout << endl << "What would you like to do?" << endl;
		cout << "1. I would like to battle an opponent" << endl;
		cout << "2. Heal Team for " << goldCost << " gold" << endl;
		cout << "3. Back out to Main menu" << endl;
		cout << ">>> ";
		cin >> choice;
		if (choice == 1)
		{
			battleHelp = false;
			system("cls");
			database.teamBattle();
		}
		if (choice == 2)
		{
			battleHelp = false;
			if (database.getGold() >= goldCost) {
				database.healUs(goldCost);
			}
			else {
				cout << "\n\nYou don't have enough gold!\n";
			}
		}
	}
	else {
		cout << "1. Start Battle" << endl;
		cout << "2. Heal Team for " << goldCost << " gold" << endl;
		cout << "3. Exit" << endl << endl;
		int battleChoice;
		cin >> battleChoice;
		switch (battleChoice) {
		case 1:
			system("cls");
			database.teamBattle();
			break;
		case 2:
			if (database.getGold() >= goldCost) {
				database.healUs(goldCost);
			}
			else {
				cout << "\n\nYou don't have enough gold!\n";
			}
			break;
		case 3:
		default:
			return;
		}
	}
}

/*
Purchase New Hero Menu

Show current gold and how much is to be subtracted
use Database::purchaseNewHero(int goldCost) to create and insert the new hero which returns back a pointer to be used
Display the new hero
*/
void purchaseMenu(Database<SmashHero>& database) 
{
	cout << "=================================================" << endl;
	cout << "====================Gachapon=====================" << endl;
	cout << "=================================================" << endl;
	double goldCost = 1000;
	if (database.getGold() >= goldCost)
	{
		cout << "Key\tName\tRarity" << endl;
		SmashHero* newHero = database.purchaseNewHero(goldCost);
		if (newHero != nullptr) {
			cout << *newHero;
			cout << "\nYou now have " << database.getGold() << " gold.\n\n";
		}
		else {
			cout << "Unexpected error.\n\n";
			return;
		}
	}
	else 
	{
		cout << "You do not have enough gold to use the Gachapon!\n";
		cout << "\nYou currently have " << database.getGold() << " gold.\n\n";
	}
}

/*
Sell Menu
Prompt user for a primary key to be deleted
use Database::displayHero(int primaryKey)
Confirm delete
use Database::sellHero(int primaryKey)
*/
void sellMenu(Database<SmashHero>& database) 
{
	cout << "=================================================" << endl;
	cout << "====================Sell Menu====================" << endl;
	cout << "=================================================" << endl;
	cout << "Please enter the key of a hero you would like to sell: ";
	int primaryKey;
	cin >> primaryKey;
	cout << endl;
	database.displayHero(primaryKey);
	cout << "\nIs this the hero you would like to sell?(Y/N): ";
	char sellChoice;
	cin >> sellChoice;
	if (sellChoice == 'N' || sellChoice == 'n') 
	{
		return;
	}
	database.sellHero(primaryKey);
}

/*
Hero List Menu
Database::displayHeroList()
*/
void heroListMenu(Database<SmashHero>& database) 
{
	database.displayHeroList();
	cout << endl << endl;
}

/*
Team List Menu

Display Team function call
Prompt user for which slot they want to replace
Prompt user for a primary key they own to be put into that slot
Swap Team Member function call
*/
void teamMenu(Database<SmashHero>& database) 
{
	cout << "=================================================" << endl;
	cout << "====================Team Menu====================" << endl;
	cout << "=================================================" << endl;
	database.displayTeam();
	cout << "\nWhich slot would you like to swap?(6 for exit)";
	int slotChoice;
	cin >> slotChoice;
	if (slotChoice >= 6 || slotChoice <= 0) 
	{
		return;
	}
	cout << "\nWhat hero would you like to put in slot " << slotChoice << "?(Enter hero key) ";
	int swapKey;
	cin >> swapKey;
	cout << "\n\nYou swapped in this hero into slot " << slotChoice << "!\n";
	database.displayHero(swapKey);
	cout << endl << endl;
	database.swapTeamMember(slotChoice, swapKey);
}

/*
Options Menu
Extra menu options for project requirements
1. Add new data							= Database::addCustomHero(string attributeLine)
2. Delete data							= Database::sellHero(int primaryKey)
3. Find and display using primary key	= Database::displayHero(int primaryKey)
4. List data in hash table sequence		= Database::displayHeroList()
5. List data in key sequence (sorted)	= Database::displayOrderedList()
6. Print indented tree					= Database::printIndentedTree()
7. Efficiency							= Database::displayEfficiency()
8. Exit (Team Choice is the battle menu)
*/
void optionsMenu(Database<SmashHero>& database) 
{
	cout << "=================================================" << endl;
	cout << "=================Options Menu====================" << endl;
	cout << "=================================================" << endl;
	cout << "1. Add Custom Data" << endl;
	cout << "2. Delete Data" << endl;
	cout << "3. Display Data using Primary Key" << endl;
	cout << "4. List Data in Hash Table Sequence" << endl;
	cout << "5. List Data in Sorted Key Sequence" << endl;
	cout << "6. Print Indented Tree" << endl;
	cout << "7. Display Efficiency" << endl;
	cout << "8. Exit" << endl;

	int optionsChoice, primaryKey;
	string attributeLine, customKey, customName, customRarity;
	cin >> optionsChoice;

	switch (optionsChoice) {
	case 1:
		system("cls");
		cout << "=================================================" << endl;
		cout << "=================Add Custom Hero=================" << endl;
		cout << "=================================================" << endl;
		cout << "Please enter a primary key: ";
		cin >> customKey;
		cout << "\nPlease enter a name: ";
		cin >> customName;
		cout << "\nPlease enter a rarity index(1-4): ";
		cin >> customRarity;
		attributeLine = customKey + '\t' + customName + '\t' + customRarity + '\t';
		database.addCustomHero(attributeLine);
		cout << "\nYou added this hero\n" << *database.getHero(stoi(customKey)) << endl;
		break;
	case 2:
		system("cls");
		sellMenu(database);
		break;
	case 3:
		system("cls");
		cout << "=================================================" << endl;
		cout << "====================Search Hero==================" << endl;
		cout << "=================================================" << endl;
		cout << "Please enter a primary Key: ";
		cin >> primaryKey;
		cout << "\nThis is the hero you inserted\n";
		database.displayHero(primaryKey);
		cout << endl << endl;
		break;
	case 4:
		system("cls");
		heroListMenu(database);
		break;
	case 5:
		system("cls");
		cout << "=================================================" << endl;
		cout << "===================Ordered List==================" << endl;
		cout << "=================================================" << endl;
		database.displayOrderedList();
		break;
	case 6:
		system("cls");
		cout << "=================================================" << endl;
		cout << "==================Indented Tree==================" << endl;
		cout << "=================================================" << endl;
		database.printIndentedTree();
		break;
	case 7:
		system("cls");
		cout << "=================================================" << endl;
		cout << "==================Display Efficiency=============" << endl;
		cout << "=================================================" << endl;
		database.displayEfficiency();
		break;
	case 8:
		return;
	default:
		return;
	}
}